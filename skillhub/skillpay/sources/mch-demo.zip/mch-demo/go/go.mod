module weixinpay-x402-demo

go 1.21

require (
	github.com/wechatpay-apiv3/wechatpay-go v0.2.20
)
